import torch
import torch.nn as nn
import ResNet
from scipy import io
import numpy 
import lmmd
from wassertaian_distance import calculate_2_wasserstein_dist
from Wgot import Wasserstein_GP
from Coral_obsi import CORAL, LOG_CORAL, CORAL_loss, softmax_kl_loss
#from log_coral_loss import LOG_CORAL
from entropy_obsi import Entropy
import CKButils
import batchnormloss
import tsneplot
#Tsne vizualization
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.manifold import TSNE
import umap
import slicewd_loss
import swdloss
import Wloss
import mmd
import gsw
import contrastive_loss
class DSAN(nn.Module):
    def __init__(self, num_classes=31, bottle_neck=True):
        super(DSAN, self).__init__()

        self.feature_layers = ResNet.resnet50(True)
        self.lmmd_loss = lmmd.LMMD_loss(class_num=num_classes)
        self.gsw_loss = gsw.GSW()
        self.cont_loss=contrastive_loss.ContrastiveLoss()
        #self.ckb_loss= CKButils.CKB_Metric(class_num=num_classes)
        #self.tsne = tsneplot(class_num=num_classes)
        self.bottle_neck = bottle_neck
        if bottle_neck:
            self.bottle = nn.Linear(2048, 256)
            self.cls_fc = nn.Linear(256, num_classes)

        else:
            self.cls_fc = nn.Linear(2048, num_classes)


    def forward(self, source, target, s_label,t_label):
        source = self.feature_layers(source)
        if self.bottle_neck:
            source = self.bottle(source)
        s_pred = self.cls_fc(source)



        target = self.feature_layers(target)
        if self.bottle_neck:
            target = self.bottle(target)
            #print("Target features")
            #print(target.shape)
        t_label = self.cls_fc(target)
        #change to numpy arrays by obsa
        
        # print("#################### Jesus is lord!!!!!!!!!!!!!!!!!!!!!!")
        # print(source.shape) #32X256
        # print(target.shape)  #32X256

        # #Affter domain adpation

        # #Xs=np.array(source)
        # #Xs=source.to('cpu').numpy()
        # Xs=source.cpu().detach().numpy()
        # #print("Source data!!!!!")
        # #print(Xs.shape)
         

        # #Xt=np.array(target)
        # #Xt=target.to('cpu').numpy()
        # Xt=target.cpu().detach().numpy()

        # #ys=np.array(s_label)
        # #Ys=s_label.to('cpu').numpy()
        # Ys=s_label.cpu().detach().numpy()
        # #yt=np.array(t_label)
        # #Yt=t_label.to('cpu').numpy()
        # Yt=t_label.cpu().detach().numpy()
        # io.savemat('X_source.mat', dict(Xs=Xs,Ys=Ys))
        # io.savemat('x_target.mat', dict(Xt=Xt,Yt=Yt))
  

        coral_loss=0
        wasserstein_loss=0
        wloss=0
        swd_loss=0
        cont_loss=0
        loss_lmmd = self.lmmd_loss.get_loss(source, target, s_label, torch.nn.functional.softmax(t_label, dim=1))

        gsw_loss=self.gsw_loss.gsw(source, target)  #GSW sliced loss

        mmd_loss=mmd.mmd_linear(source,target)

        #wloss=Wloss.torch_wasserstein_loss(source,target)



       #Sliced  Wasserstein distance


        swd_loss+= swdloss.sliced_WD_loss_function(source, target) #Working 
        #swd_loss+=swdloss.discrepancy_slice_wasserstein(source, target)




        #BSliced WD loss
        #slwd_loss = slicewd_loss.sliced_wasserstein_distance(s_pred,t_label, embed_dim=31)

        



        #def CKB_Metric(fea_s, fea_t, lab_s, plab_t, prob_t, class_num=31, epsilon=1e-2, CKB_type='soft'):
        # btchnormloss=0
        # btchnormloss+=batchnormloss.BNM(source,target)




        coral_loss += CORAL(source, target)

        #wasserstein_loss+= calculate_2_wasserstein_dist(source, target) #working


        #contrastive loss 

        cont_loss+=self.cont_loss.forward(source, target)


        #wgd_loss+= Wasserstein_GP(source, target) #working
        #coral_loss += softmax_kl_loss(source,target)  # KL-divergence
    
        
        return s_pred,source,target,loss_lmmd,swd_loss,coral_loss, mmd_loss, gsw_loss,cont_loss  #,slwd_loss  ,wasserstein_loss,    #,wgd_loss       #slwd_loss           #,btchnormloss              #loss_lmmd,    #coral_loss    #Match_loss         #coral_loss

    def predict(self, x):
        x = self.feature_layers(x)
        #print("After prediction", x.shape)
        #Xs=x.cpu().detach().numpy()
        #Ys=s_label.cpu().detach().numpy()
       # io.savemat('X_source2.mat', dict(Xs=Xs))

        if self.bottle_neck:
            x = self.bottle(x)
        return self.cls_fc(x)

        