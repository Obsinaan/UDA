import torch
import torch.nn.functional as F
import torch.nn as nn
import math
import argparse
import numpy as np
import numpy
import os
from scipy import io
from entropy_obsi import entropy_loss,Entropy

from DSAN import DSAN
import data_loader
import data_loader_obsi
import os
from labelsmooth_obsi import CrossEntropyLabelSmooth
import CKButils
import batchnormloss
import Deepjdot
import slicewd_loss
os.environ['CUDA_VISIBLE_DEVICES']="1"
#torch.cuda.empty_cache()

def load_data(root_path, src, tar, batch_size):
    kwargs = {'num_workers': 1, 'pin_memory': True}
    loader_src = data_loader.load_training(root_path, src, batch_size, kwargs)
    loader_tar = data_loader.load_training(root_path, tar, batch_size, kwargs)
    loader_tar_test = data_loader.load_testing(
        root_path, tar, batch_size, kwargs)
    return loader_src, loader_tar, loader_tar_test


def train_epoch(epoch, model, dataloaders, optimizer):

    model.train()
    source_loader, target_train_loader, _ = dataloaders
    iter_source = iter(source_loader)
    iter_target = iter(target_train_loader)
    num_iter = len(source_loader)
    for i in range(1, num_iter):
        data_source, label_source = iter_source.next()
        data_target,label_target = iter_target.next()  #I added labe_target ,_
        if i % len(target_train_loader) == 0:
            iter_target = iter(target_train_loader)
        data_source, label_source = data_source.cuda(), label_source.cuda()
        data_target,label_target=data_target.cuda(),label_target.cuda() # I have added for seek of trget label
        data_target = data_target.cuda()

        optimizer.zero_grad()
        label_source_pred,source_pred,target_pred,loss_lmmd,swd_loss,coral_loss,wasserstein_loss,mmd_loss,gsw_loss= model(data_source, data_target, label_source,label_target)   #, coral_loss
       #coral_loss=model(data_source,data_target)  #, coral_loss
        #Entropy loss obsi
        #tar_Ent_loss = Tar_Ent_lambda*CKButils.Entropy(prob_t)
        #print("target predict",target_pred.shape)
        

        trg_softmax = F.softmax(target_pred,dim=1)
        # print('trg_softmax',trg_softmax.shape) #32X256
        # print('source_pred', source_pred.shape) #32X256

        #print(trg_softmax.shape)
        entropyloss=0
        #tar_cl_loss=1.0, sloss=0.0, tloss=1.0, jdot_alpha=0.01
        
        entropyloss+=entropy_loss(trg_softmax)
        #print(entropyloss)

        #Classification loss

        loss_cls = F.nll_loss(F.log_softmax(
            label_source_pred, dim=1), label_source)
        # print("source", label_source_pred.shape) # 32X56
        # print("ground truth source", label_source.shape) # 32

        # # Target and source label loss
         
        # # loss calculation based on double sum (sum_ij (ys^i, ypred_t^j))
        # label_loss = -torch.matmul(source_pred, torch.transpose(trg_softmax,1,0))

        # print("label_loss", label_loss) # 32X32

        # loss_cls=loss_cls + label_loss

        

        

        









        # btchnormloss=batchnormloss.BNM(label_source_pred,target_pred)
        # X_s, lab_s = CKButils.to_var(data_source), CKButils.to_var(label_source)
        # X_t, lab_t = CKButils.to_var(data_target), CKButils.to_var(label_target)
        # #Z_s, prob_s =model(X_s)
        # #Z_t, prob_t = model(X_t)
        # plab_t = t_label.detach().max(1)[1]
        # loss_ckb = args.CKB_lambda*CKButils.CKB_Metric(X_s,X_t,lab_s,plab_t,t_label,args.nclass, args.inv_epsilon, args.CKB_type)

        # plab_t = t_label.detach().max(1)[1]


        # loss_ckb =args.CKB_lambda * CKButils.CKB_Metric(source_pred,target_pred ,s_label,plab_t,t_label,args.nclass, args.inv_epsilon, args.CKB_type)
        


        #labelsmoothing 
        #loss_cls = CrossEntropyLabelSmooth(num_classes=args.nclass, epsilon=args.smooth)(label_source_pred, label_source) 

        #loss_l1 = F.L1Loss()
        # # Discriminative loss

        # #discrepency_loss = torch.mean(abs(F.softmax(pred_tar_1, dim=1) - F.softmax(pred_tar_2, dim=1)))
        # entropyloss+= loss_l1(F.softmax(target_pred,dim=1), F.softmax(target_pred, dim=1))
        # discrepency_loss.backward()
        alpha=0.5
        # #Slice wesertstein diistance working
        # slwd_loss=0
        # slwd_loss+=loss_cls-slwd_loss + 0.01  


        lambd = 2 / (1 + math.exp(-10 * (epoch) / args.nepoch)) - 1
        # l1_loss = torch.abs(torch.nn.functional.softmax(data_source, dim=1) - torch.nn.functional.softmax(data_target, dim=1))
        # l1_loss = torch.mean(l1_loss)
        #loss =  loss_cls + args.weight * lambd * (loss_lmmd + coral_loss) + lambd * wasserstein_loss + lambd * entropyloss   #+wasserstein_loss coral_loss + lambd * entropyloss                             
        loss = loss_cls + args.weight * lambd * loss_lmmd + lambd * swd_loss    # + lambd * entropyloss  #      args.weight * lambd * loss_lmmd    + lambd * entropyloss  #+ lambd * wasserstein_loss + lambd * entropyloss
        loss.backward()
        optimizer.step()

        if i % args.log_interval == 0:
            print(f'Epoch: [{epoch:2d}], Loss: {loss.item():.4f}, loss_cls: {loss_cls.item():.4f}, loss_lmmd: {loss_lmmd.item():.4f},slwd_loss: {swd_loss.item():.4f}') #' ,entropy_loss: {entropyloss.item():.4f}')  #' loss_lmmd: {loss_lmmd.item():.4f},coral_loss: {coral_loss.item():.4f},wasserstein_loss: {wasserstein_loss.item():.4f},entropy_loss: {entropyloss.item():.4f}')  #,slwd_loss: {slwd_loss.item():.4f} ,coral_loss: {coral_loss.item():.4f},entropy_loss: {entropyloss.item():.4f},coral_loss: {coral_loss.item():.4f},entropy_loss: {entropyloss.item():.4f}')  #,entropy_loss: {entropyloss.item():.4f}
        #  Working  generating matlab file for tsne plot

            # Xs=src_pred.cpu().detach().numpy()
            # print(source_pred.shape)
            # Xt=tgt_data.cpu().detach().numpy()
            # print(target_pred.shape)
            # Ys=src_label.cpu().detach().numpy()
            # print(label_source.shape)
            # Yt=t_label_label.cpu().detach().numpy()
            # print(label_target.shape)
            # # # #Xss = np.zeros(shape=(1, 65))
            # # # #Xss=np.append(Xss,Xs,axis=0)
            # Xss=[]
            # Xtt=[]
            # yss=[]
            # ytt=[]
            # # # #for epoch in nepoch:
            # # # #for epoch in range(1, args.nepoch + 1):

            # for i in range(1, iteration+1):
            #     Xss.append(Xs)
            #     Xtt.append(Xt)
            #     yss.append(Ys)
            #     ytt.append(Yt)
               

            # # #     #Ys=label_source.cpu().detach().numpy()
            # # # # print(len(Xss))
            # # # # print(len(Xtt))
            # # # # print(len(yss))
            # # # # print(len(ytt))
            # Print(" after appending ")
            # Xss=np.array(Xss)
            # print(Xss.shape)
            # yss=np.array(yss)
            # print(yss.shape)

            # Xtt=np.array(Xtt)
            # print(Xtt.shape)
            # ytt=np.array(ytt)
            # print(ytt.shape)

     
            # io.savemat('AmazonDAN.mat', dict(Xs=Xss,Ys=yss))
            # io.savemat('WebcamDAN.mat', dict(Xt=Xtt,Yt=ytt))


        
        

def test(model, dataloader):
    model.eval()
    test_loss = 0
    correct = 0
    with torch.no_grad():
        for data, target in dataloader:
            data, target = data.cuda(), target.cuda()
            #print("data",data.shape)
            #print("target",target.shape)
            pred = model.predict(data)
           # print("ped",pred.shape)

            # sum up batch loss
            test_loss += F.nll_loss(F.log_softmax(pred, dim=1), target).item()
            pred = pred.data.max(1)[1]
            correct += pred.eq(target.data.view_as(pred)).cpu().sum()
        test_loss /= len(dataloader)
        print(
            f'Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(dataloader.dataset)} ({100. * correct / len(dataloader.dataset):.2f}%)')
    return correct


def get_args():
    def str2bool(v):
        if v.lower() in ('yes', 'true', 't', 'y', '1'):
            return True
        elif v.lower() in ('no', 'false', 'f', 'n', '0'):
            return False
        else:
            raise argparse.ArgumentTypeError('Unsupported value encountered.')

    parser = argparse.ArgumentParser()
    parser.add_argument('--root_path', type=str, help='Root path for dataset',
                        default='OfficeHome')                             #Office31,office_caltech_10, Modern-Office-31, image_CLEF_torch,OfficeHome,Adaptiope, office_caltech_10
    parser.add_argument('--src', type=str,
                        help='Source domain', default='Art')             #'webcam/images/'
    parser.add_argument('--tar', type=str,
                        help='Target domain', default='Clipart')
    parser.add_argument('--nclass', type=int,
                        help='Number of classes', default=65)
    parser.add_argument('--batch_size', type=float,
                        help='batch size', default=32) #32
    parser.add_argument('--nepoch', type=int,
                        help='Total epoch num', default=1000)
    parser.add_argument('--lr', type=list, help='Learning rate', default=[0.001, 0.01, 0.1])
    parser.add_argument('--early_stop', type=int,
                        help='Early stoping number', default=30) #30
    parser.add_argument('--seed', type=int,
                        help='Seed', default=2021)
    parser.add_argument('--weight', type=float,
                        help='Weight for adaptation loss', default=0.5) #0.5
    parser.add_argument('--momentum', type=float, help='Momentum', default=0.9)
    parser.add_argument('--decay', type=float,
                        help='L2 weight decay', default=5e-4)  #5e-4
    parser.add_argument('--bottleneck', type=str2bool,
                        nargs='?', const=True, default=True)
    parser.add_argument('--log_interval', type=int,
                        help='Log interval', default=10)
    parser.add_argument('--gpu', type=str,
                        help='GPU ID', default='3')
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = get_args()
    print(vars(args))
    SEED = args.seed
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

    dataloaders = load_data(args.root_path, args.src,
                            args.tar, args.batch_size)
    model = DSAN(num_classes=args.nclass).cuda()
    
    correct = 0
    stop = 0
    # # I added it
    # FC = DSAN.FC_Layers(FC_input_dim,FC_dim_1,FC_dim_2,num_cls)
    # FC.apply(CKButils.weights_init)
    # FC.cuda()
    # model.cuda()
    if args.bottleneck:
        optimizer = torch.optim.SGD([
            {'params': model.feature_layers.parameters()},                           #SGD-ADAM
            {'params': model.bottle.parameters(), 'lr': args.lr[1]},
            {'params': model.cls_fc.parameters(), 'lr': args.lr[2]},
        ], lr=args.lr[0],momentum=args.momentum, weight_decay=args.decay)                                   #momentum=args.momentum,
    else:
        optimizer = torch.optim.Adam([
            {'params': model.feature_layers.parameters()},
            {'params': model.cls_fc.parameters(), 'lr': args.lr[1]},
        ], lr=args.lr[0], momentum=args.momentum, weight_decay=args.decay)                                   #momentum=args.momentum


    for epoch in range(1, args.nepoch + 1):
        stop += 1
        for index, param_group in enumerate(optimizer.param_groups):
            param_group['lr'] = args.lr[index] / math.pow((1 + 10 * (epoch - 1) / args.nepoch), 0.75)

        train_epoch(epoch, model, dataloaders, optimizer)
        t_correct = test(model, dataloaders[-1])
        if t_correct > correct:
            correct = t_correct
            stop = 0
            torch.save(model, 'model.pkl')
            #torch.save(model,'model.mat')
            #Xs=dataloaders.cpu().detach().numpy()
            #io.savemat('Xst.mat', dict(Xs=Xst))


            # # dfaeture generated saving 

            # for i in range(len(target)):
        
        # Xt=target.cpu().detach().numpy()
        # Ys=s_label.cpu().detach().numpy()
        # Yt=t_label.cpu().detach().numpy()
        # io.savemat('X_source.mat', dict(Xs=Xs,Ys=Ys))
        # io.savemat('x_target.mat', dict(Xt=Xt,Yt=Yt))

  
        print(
            f'{args.src}-{args.tar}: max correct: {correct} max accuracy: {100. * correct / len(dataloaders[-1].dataset):.2f}%\n')

        if stop >= args.early_stop:
            print(
                f'Final test acc: {100. * correct / len(dataloaders[-1].dataset):.2f}%')
            break
        